import comtypes.client as cc

def block_ip(ip_address):
    try:
        fwMgr = cc.CreateObject("HNetCfg.FwMgr")
        profile = fwMgr.LocalPolicy.CurrentProfile
        policy = profile.GloballyOpenPorts
        
        # Add a block rule (this is simplified)
        print(f"Blocking IP: {ip_address}")
        # Actual implementation would use Windows Firewall COM interface
        
    except Exception as e:
        print(f"Error: {e}")

# Example usage
block_ip("192.168.1.100")